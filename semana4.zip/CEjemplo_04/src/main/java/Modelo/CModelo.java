/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author USER 17
 */
public class CModelo {
    private double lado;
    private double area;
    private double perimetro;

    public void setLado(double lado) {
        this.lado = lado;
        calcularArea();
        calcularPerimetro();
    }

    public double getLado() {
        return lado;
    }

    public double getArea() {
        return area;
    }

    public double getPerimetro() {
        return perimetro;
    }

    private void calcularArea() {
        this.area = lado * lado;
    }

    private void calcularPerimetro() {
        this.perimetro = 4 * lado;
    }
}
