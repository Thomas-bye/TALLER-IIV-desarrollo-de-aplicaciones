/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.CModelo;
import Vista.CVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author USER 17
 */
public class CControlador implements ActionListener {

    private CModelo modelo;
    private CVista vista;

    public CControlador(CModelo modelo, CVista vista) {
        this.modelo = modelo;
        this.vista = vista;
        this.vista.getBtnCalcular().addActionListener(this);
        this.vista.getBtnNuevo().addActionListener(this); // 
        this.vista.getBtnSalir().addActionListener(this); //
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.getBtnCalcular()) {
            double lado = vista.getLado();
            modelo.setLado(lado);
            vista.setAreaResultado(modelo.getArea());
            vista.setPerimetroResultado(modelo.getPerimetro());
        } else if (e.getSource() == vista.getBtnNuevo()) {
            vista.limpiarCampos(); // Llamar al método para limpiar los campos
            modelo.setLado(0); // Opcional: resetear el modelo si es necesario
        } else if (e.getSource() == vista.getBtnSalir()) {
            System.exit(0); // Cerrar la aplicación
        }
    }

}
