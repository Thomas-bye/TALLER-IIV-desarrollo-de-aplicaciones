/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.cejemplo_04;

import Controlador.CControlador;
import Modelo.CModelo;
import Vista.CVista;

/**
 *
 * @author USER 17
 */
public class CEjemplo_04 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        CModelo modelo = new CModelo();
        CVista vista = new CVista();
        vista.setVisible(true);
        CControlador controlar = new CControlador(modelo, vista);
    }
    /*// Crear instancias del Modelo, la Vista y el Controlador
        ModeloCuadrado modelo = new ModeloCuadrado();
        VistaCuadrado vista = new VistaCuadrado();
        ControladorCuadrado controlador = new ControladorCuadrado(modelo, vista);*/
}
