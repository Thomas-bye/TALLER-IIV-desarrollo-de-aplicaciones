/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.csemana02;

import Actividad.Actividad01;
import Actividad.Actividad02;

/**
 *
 * @author USUARIO
 */
public class CSemana02 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        /*
        Actividad01 act = new Actividad01();
        act.setVisible(true);
        */
        Actividad02 acti = new Actividad02();
        acti.setVisible(true);
        
    }
}
