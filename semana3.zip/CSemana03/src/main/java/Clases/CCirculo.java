/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author USUARIO
 */
public class CCirculo {
    private float radio;

    public CCirculo() {
    }

    public CCirculo(float radio) {
        this.radio = radio;
    }

    public float getRadio() {
        return radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }

   ///hallar area
    public float hallarArea(){
        float area;
        area = (float) ((float) Math.PI * Math.pow(radio, 2));
        return area;
    }
    
    //meto mostrar
    public float mostrarArea(){
        return hallarArea();
    }
}
