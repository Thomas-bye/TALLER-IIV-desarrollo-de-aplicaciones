/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author USUARIO
 */
public class CCuadrado {

    private float lado;

    public CCuadrado() {
    }

    public CCuadrado(float lado) {
        this.lado = lado;
    }

    public float getLado() {
        return lado;
    }

    public void setLado(float lado) {
        this.lado = lado;
    }

    //metodo para hallar area
    public float hallarArea() {
        float area;
        area = (float) Math.pow(lado, 2);
        return area;
    }

    //meto mostrar
    public float mostrarArea() {
        return hallarArea();
    }
}
