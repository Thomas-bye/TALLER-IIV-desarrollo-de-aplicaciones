/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author USUARIO
 */
public class CRectangulo {

    float base, ancho;

    public CRectangulo() {
    }

    public CRectangulo(float base, float ancho) {
        this.base = base;
        this.ancho = ancho;
    }

    public float getBase() {
        return base;
    }

    public void setBase(float base) {
        this.base = base;
    }

    public float getAncho() {
        return ancho;
    }

    public void setAncho(float ancho) {
        this.ancho = ancho;
    }

    //metodo para hallar area
    public float hallarArea() {
        float area;
        area = (float) Math.pow(base, ancho);
        return area;
    }

    //meto mostrar
    public float mostrarArea() {
        return hallarArea();
    }

}
