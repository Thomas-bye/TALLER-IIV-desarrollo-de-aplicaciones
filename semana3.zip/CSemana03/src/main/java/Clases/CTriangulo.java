/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author USUARIO
 */
public class CTriangulo {

    private float base, alatura;

    public CTriangulo() {
    }

    public CTriangulo(float base, float alatura) {
        this.base = base;
        this.alatura = alatura;
    }

    public float getBase() {
        return base;
    }

    public void setBase(float base) {
        this.base = base;
    }

    public float getAlatura() {
        return alatura;
    }

    public void setAlatura(float alatura) {
        this.alatura = alatura;
    }

    //hallar area
    public float hallarArea() {
        float area;
        area = (float) Math.pow(base, alatura) / 2;
        return area;
    }

    //meto mostrar
    public float mostrarArea() {
        return hallarArea();
    }
}
