/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.csemana03;

import Vistas.VLogin;
import Vistas.VPrincipal;

/**
 *
 * @author USUARIO
 */
public class CSemana03 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        //VLogin log = new VLogin();
        //log.setVisible(true);
        VPrincipal obj = new VPrincipal();
        obj.setVisible(true);
    }
}
