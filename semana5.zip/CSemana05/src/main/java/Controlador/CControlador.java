/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.CModelo;
import Vista.CVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author USUARIO
 */
public class CControlador implements ActionListener{

    private CVista vista;
    private CModelo modelo;

    public CControlador(CVista vista) {
        this.vista = vista;
        this.modelo = new CModelo();

        // Registrar los listeners usando los nuevos métodos
        vista.agregarGuardarListener(this);
        vista.agregarNuevoListener(this);
        vista.agregarSalirListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();

        switch (comando) {
            case "guardar":
                guardarDatos();
                break;

            case "nuevo":
                limpiarCampos();
                break;

            case "salir":
                confirmarSalida();
                break;
        }
    }

    private void guardarDatos() {
        // Obtener datos de la vista
        String codigo = vista.obtenerCodigo();
        String dni = vista.obtenerDNI();
        String apellidos = vista.obtenerApellidos();
        String nombres = vista.obtenerNombres();
        String facultad = vista.facultad();
        String carrera = vista.obtenerCarrera();

        // Actualizar el modelo
        modelo.setCodigo(codigo);
        modelo.setDni(dni);
        modelo.setApellidos(apellidos);
        modelo.setNombres(nombres);
        modelo.setFacultad(facultad);
        modelo.setCarrera(carrera);

        // Mostrar resultados en la vista
        vista.mostrarResultado(
                modelo.getCodigo(),
                modelo.getDni(),
                modelo.getApellidos(),
                modelo.getNombres(),
                modelo.getFacultad(),
                modelo.getCarrera()
        );
    }

    private void limpiarCampos() {
        vista.nuevo();
    }

    private void confirmarSalida() {
        int opcion = JOptionPane.showConfirmDialog(
                vista,
                "¿Está seguro que desea salir?",
                "Confirmar Salida",
                JOptionPane.YES_NO_OPTION
        );

        if (opcion == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

}
