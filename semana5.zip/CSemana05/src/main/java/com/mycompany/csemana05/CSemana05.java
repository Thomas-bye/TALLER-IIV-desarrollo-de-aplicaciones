/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.csemana05;

import Controlador.CControlador;
import Vista.CVista;

/**
 *
 * @author USUARIO
 */
public class CSemana05 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        //view.setVisible(true);
            CVista vista = new CVista();
            new CControlador(vista);
            vista.setVisible(true);
     
        
        
    }
}
