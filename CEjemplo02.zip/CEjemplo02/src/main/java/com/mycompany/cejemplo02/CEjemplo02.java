/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cejemplo02;

import Semana02.CEjercio01;

/**
 *
 * @author USER 17
 */
public class CEjemplo02 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        CEjercio01 pension = new CEjercio01();
        pension.setVisible(true);
    }
}
